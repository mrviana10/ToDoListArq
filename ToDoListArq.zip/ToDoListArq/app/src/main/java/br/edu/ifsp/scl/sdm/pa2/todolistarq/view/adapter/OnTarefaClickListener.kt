package br.edu.ifsp.scl.sdm.pa2.todolistarq.view.adapter

interface OnTarefaClickListener {
    fun onTarefaClick(posicao: Int)
}